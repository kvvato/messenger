package com.example.messenger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessengerApplicationTests {

    @Test
    void contextLoads() {
    }

}
